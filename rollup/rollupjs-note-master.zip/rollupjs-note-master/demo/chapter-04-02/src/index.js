import Vue from 'vue/dist/vue';
import App from './App.vue';

new Vue({
  el: '#App',
  render: h => h(App),
})
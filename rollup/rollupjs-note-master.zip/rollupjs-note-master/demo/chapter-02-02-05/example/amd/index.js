define(function (require) {
  var demo = require('lib/demo');
  demo.init()
});

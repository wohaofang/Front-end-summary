class Demo {
	constructor(data) {
		this.data = data;
	}
	
	logData() {
		console.log('data is : ', this.data);
	}
}

export default Demo
require('babel-polyfill');
const demo = require('./../dist/index');

demo.init();
